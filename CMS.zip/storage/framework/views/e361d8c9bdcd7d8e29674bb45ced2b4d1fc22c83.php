<?php $__env->startSection('con'); ?>
<div class="card card-default">
    <div class="card-header">Edit Post</div>
    <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card-body">
        <form action="<?php echo e(route('posts.update', $post->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="form-group">
              <label for="title">Title</label>
              <input type="text"
                class="form-control" name="title" value="<?php echo e($post->title); ?>">
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <input type="text"
                  class="form-control" name="description" value="<?php echo e($post->description); ?>">
              </div>
            <div class="form-group">
                <button type="submit" class="btn btn-success">Update Post</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\CMS\resources\views/posts/edit.blade.php ENDPATH**/ ?>