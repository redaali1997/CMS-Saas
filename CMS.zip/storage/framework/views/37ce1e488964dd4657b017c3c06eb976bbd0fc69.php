<?php $__env->startSection('con'); ?>
<div class="d-flex justify-content-end mb-2">
    <a href="<?php echo e(route('tags.create')); ?>" class="btn btn-success">Add tag</a>
</div>
<div class="card card-default">
    <div class="card-header">tags</div>
    <div class="card-body">
        <?php if($tags->count() > 0): ?>
        <table class="table">
            <thead>
                <th>Name</th>
                <th>Posts Count</th>
                <?php if(auth()->user()->isAdmin()): ?>
                <th></th>
                <?php endif; ?>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($tag->name); ?>

                    </td>
                    <td>
                        <?php echo e($tag->posts->count()); ?>

                    </td>
                    <?php if(auth()->user()->isAdmin()): ?>
                    <td>
                        <a href="<?php echo e(route('tags.edit', $tag->id)); ?>" class="btn btn-info btn-sm">
                            Edit
                        </a>
                        <button class="btn btn-danger btn-sm" onclick="handleDelete(<?php echo e($tag->id); ?>)">
                            Delete
                        </button>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php else: ?>
        <h3 class="text-center">
            No tags Yet.
        </h3>
        <?php endif; ?>

        <form action="" method="post" id="deleteForm">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Delete tag</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            Are you sure to delete this tag ?
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">No, Go back!</button>
                            <button type="submit" class="btn btn-danger">Yes, Delete</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function handleDelete(id){
            var form = document.getElementById('deleteForm')
            form.action = '/tags/' + id
            $('#deleteModal').modal('show')
        }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\CMS\resources\views/tags/index.blade.php ENDPATH**/ ?>